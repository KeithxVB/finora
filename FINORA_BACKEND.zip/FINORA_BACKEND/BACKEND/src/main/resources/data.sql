INSERT INTO categories (name, icon, color, type) VALUES
('Food', 'food_icon', '#ff4d4f', 'expense'),
('Salary', 'salary_icon', '#52c41a', 'income');
